import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TaskService } from './../shared/services/task.service';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {

  taskId: number;
  submitData: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private editTaskService: TaskService
  ) { }

  getTaskById() {
    this.taskId = this.activatedRoute.snapshot.params.id;
    this.editTaskService.getTaskById(this.taskId).subscribe(data => {
      console.log(data);
      this.submitData = data;
      console.log(this.submitData);
    });
    console.log(this.taskId);
  }

  ngOnInit() {
    this.getTaskById();
  }

}
