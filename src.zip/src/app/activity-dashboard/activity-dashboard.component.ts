import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity-dashboard',
  templateUrl: './activity-dashboard.component.html',
  styleUrls: ['./activity-dashboard.component.css']
})
export class ActivityDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
