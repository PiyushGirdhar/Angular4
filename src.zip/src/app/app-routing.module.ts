import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';

// Components
import { ActivityDashboardComponent } from './activity-dashboard/activity-dashboard.component';
import { TaskViewComponent } from './task-view/task-view.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { EditTaskComponent } from './edit-task/edit-task.component';
import { FileUploadComponent } from './file-upload/file-upload.component';

const appRoutes: Routes = [
    {
        path: '',
        component: TaskViewComponent
    },
    {
        path: 'activity-dashboard',
        component: ActivityDashboardComponent
    },
    {
        path: 'add-task',
        component: AddTaskComponent
    },
    {
        path: 'edit-task/:id',
        component: EditTaskComponent
    },
    {
        path: 'file-upload',
        component: FileUploadComponent
    },
    {
        path: '**',
        component: TaskViewComponent
    }
];

@NgModule({
    declarations: [],
    imports: [ RouterModule.forRoot(appRoutes) ],
    providers: [],
    bootstrap: [],
    exports: [ RouterModule ]
})

export class AppRoutingModule { }
