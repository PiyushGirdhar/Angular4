import { SearchTextPipe } from './search-text.pipe';

describe('SearchTextPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchTextPipe();
    expect(pipe).toBeTruthy();
  });
});
