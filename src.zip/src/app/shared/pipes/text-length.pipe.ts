import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'textLength'
})
export class TextLengthPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (!value) { return; }
    return value.replace(/.(?=.{6})/g, '');
  }

}
