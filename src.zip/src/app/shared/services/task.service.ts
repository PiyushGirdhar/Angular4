import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Urls } from './../constants/urls';

@Injectable()
export class TaskService {

  constructor(
    private http: HttpClient,
    private urls: Urls
  ) { }

  // Get All tasks
  getAllTask() {
    return this.http.get(this.urls.baseUrl + this.urls.masterData + this.urls.taskmaster);
  }

  // Submit Task
  submitTask(data) {
    return this.http.post(this.urls.baseUrl + this.urls.masterData + this.urls.taskmaster, data);
  }

  // Get Task Type
  getTaskType() {
    return this.http.get(this.urls.baseUrl + this.urls.masterData + this.urls.referenceType + this.urls.taskType);
  }

  // Get Task Action
  getTaskAction() {
    return this.http.get(this.urls.baseUrl + this.urls.masterData + this.urls.referenceType + this.urls.taskAction);
  }

  // Get Task Owned By Team
  getTaskOwnedBy() {
    return this.http.get(this.urls.baseUrl + this.urls.masterData + this.urls.referenceType + this.urls.taskOwnedBy);
  }

  // Get Frequency
  getFrequency() {
    return this.http.get(this.urls.baseUrl + this.urls.masterData + this.urls.referenceType + this.urls.frequency);
  }

  // Get Sla Region
  getSlaRegion() {
    return this.http.get(this.urls.baseUrl + this.urls.masterData + this.urls.referenceType + this.urls.slaRegion);
  }

  // Get File Type
  getFileType() {
    return this.http.get(this.urls.baseUrl + this.urls.masterData + this.urls.referenceType + this.urls.fileType);
  }

  // Get File Format
  getFileFormat() {
    return this.http.get(this.urls.baseUrl + this.urls.masterData + this.urls.referenceType + this.urls.fileFormat);
  }

  // Get Folder Date Format
  getFolderDateFormat() {
    return this.http.get(this.urls.baseUrl + this.urls.masterData + this.urls.referenceType + this.urls.folderDateFormat);
  }

  // Get Accounts
  getAccounts() {
    return this.http.get(this.urls.referenceUrl + this.urls.accounts);
  }

  // Update Task
  getTaskById(id) {
    return this.http.get(this.urls.baseUrl + this.urls.masterData + this.urls.taskmaster + '/' + id);
  }

}
