import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Urls } from '../constants/urls';
import 'rxjs/add/operator/map';

@Injectable()
export class KerbrosAuthService {

  constructor(
    private url: Urls,
    private http: Http
  ) { }

  sendTimeStamp(timestamp: any) {
    const host = location.protocol + '//' + location.host;
    window.location.href = this.url.kerberosBaseUrl + this.url.login + host + this.url.appIdUrl
                           + this.url.appId + this.url.randumNo + timestamp;
  }

  fetchAccessToken(data) {
    return this.http.post(this.url.kerberosBaseUrl + this.url.getTokens, data).map(res => res.json());
  }

}
