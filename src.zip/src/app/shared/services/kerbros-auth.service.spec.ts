import { TestBed, inject } from '@angular/core/testing';

import { KerbrosAuthService } from './kerbros-auth.service';

describe('KerbrosAuthService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [KerbrosAuthService]
    });
  });

  it('should be created', inject([KerbrosAuthService], (service: KerbrosAuthService) => {
    expect(service).toBeTruthy();
  }));
});
