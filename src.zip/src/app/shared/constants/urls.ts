import { environment } from './../../../environments/environment';

export class Urls {

    // Kerbros setup
    kerberosBaseUrl = environment.KERBEROS_ENDPOINT;
    appId = 'TaskManagementApp';

    // Task Base url
    baseUrl = environment.API_ENDPOINT;

    // Reference Data Base Url
    referenceUrl = environment.REFERENCEDATA_ENDPOINT;

    // Endpoints
    accounts = '/clientInst';
    login = '/login?caller=';
    randumNo = '&randomno=';
    appIdUrl = '/&appId=';
    getTokens = '/fetchtokens';
    masterData = '/masterdata';
    taskmaster = '/taskmaster';
    referenceType = '/referencetype';
    taskType = '/task_type';
    taskAction = '/task_action';
    taskOwnedBy = '/owned_by';
    frequency = '/frequency';
    slaRegion = '/business_region';
    fileType = '/file_type';
    fileFormat = '/file_format';
    folderDateFormat = '/folder_date_format';

}
