export class Constants {

    // Date Format
    dateFormat = 'dd/mm/yyyy';

    // Authentication & Authorization
    timestamp = 'timestamp';
    accessToken = 'accessToken';
    refreshToken = 'refreshToken';
    aNumber = 'aNumber';

    // Pagination Config
    itemsPerPage = 5;
    currentPage = 1;

    // Form Fields
    accountList = 'accountInstApiList';
    activeFlag = 'Y';
    accountSpecific = 'ACCNT_SPECIFIC';
    fundSpecific = 'FND_SPECIFIC';
    generic = 'GEN';

}
