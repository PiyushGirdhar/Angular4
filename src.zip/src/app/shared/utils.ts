export class Utils {

    toggleSlider() {
        console.log('test');
    }

}
