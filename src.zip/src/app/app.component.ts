import { Component, OnInit } from '@angular/core';
import { KerbrosAuthService } from './shared/services/kerbros-auth.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Urls } from './shared/constants/urls';
import { Constants } from './shared/constants/constants';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  isStandAlone: boolean = true;
  aNumber: string;
  timeStampValue: any;
  runApp: boolean = false;

  constructor(
    private kerbros: KerbrosAuthService,
    private activatedRoute: ActivatedRoute,
    private url: Urls,
    private constant: Constants,
    private router: Router
  ) { }

  // Check If the app's stand-alone or embedded
  standAloneApp(): void {
    top !== self ? this.isStandAlone = false : this.isStandAlone = true;
  }

  // Check for timestamp value in local storage
  checkTimeStamp(): void {
    const timestamp = localStorage.getItem(this.constant.timestamp);
    if (timestamp == null || timestamp === '') {
      this.setTimeStamp();
    } else {
      this.timeStampValue = timestamp;
      this.getAnumber();
    }
  }

  // Set timestamp value if not available and send the value to call the api
  setTimeStamp(): void {
    this.timeStampValue = new Date().getTime();
    localStorage.setItem(this.constant.timestamp, this.timeStampValue);
    this.kerbros.sendTimeStamp(this.timeStampValue);
  }

  // Get A-Id from the parameter and get acesstokens
  getAnumber(): void {
    this.activatedRoute.queryParams.subscribe(params => {
      this.aNumber = params[this.constant.aNumber];
      const getTokensData = {
        anumber: this.aNumber,
        appId: this.url.appId,
        timeStamp: this.timeStampValue
      };
      if (!localStorage.getItem(this.constant.accessToken) && !localStorage.getItem(this.constant.refreshToken)) {
        this.getAccessToken(getTokensData);
      }
    });
  }

  // Get Access Tokens
  getAccessToken(getTokensData): void {
    if (getTokensData.anumber !== undefined) {
      this.kerbros.fetchAccessToken(getTokensData).subscribe(data => {
        localStorage.setItem(this.constant.accessToken, data.accessToken);
        localStorage.setItem(this.constant.refreshToken, data.refreshToken);
        localStorage.setItem(this.constant.aNumber, this.aNumber);
        location.reload();
        this.router.navigate(['/']);
      });
    }
  }

  // Check to show app or not if aNumber is available
  showApp(): void {
    localStorage.getItem('aNumber') ? this.aNumber = localStorage.getItem('aNumber') : this.aNumber = '';
    localStorage.getItem('aNumber') ? this.runApp = true : this.runApp = false;
  }

  ngOnInit() {
    this.standAloneApp();
    this.checkTimeStamp();
    this.showApp();
  }

}
