import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';

// Shared
import { Utils } from './shared/utils';
import { Constants } from './shared/constants/constants';
import { Urls } from './shared/constants/urls';
import { KerbrosAuthService } from './shared/services/kerbros-auth.service';
import { AppInterceptorService } from './shared/services/app-interceptor.service';
import { TaskService } from './shared/services/task.service';

// Third Party Libraries/Modules
import { NgxPaginationModule } from 'ngx-pagination';
import { MyDatePickerModule } from 'mydatepicker';

// Components
import { AppComponent } from './app.component';
import { TaskViewComponent } from './task-view/task-view.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { EditTaskComponent } from './edit-task/edit-task.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { ActivityDashboardComponent } from './activity-dashboard/activity-dashboard.component';

// Pipes
import { TextLengthPipe } from './shared/pipes/text-length.pipe';
import { SearchTextPipe } from './shared/pipes/search-text.pipe';

@NgModule({
  declarations: [
    AppComponent,
    TaskViewComponent,
    AddTaskComponent,
    EditTaskComponent,
    FileUploadComponent,
    ActivityDashboardComponent,
    TextLengthPipe,
    SearchTextPipe
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    NgxPaginationModule,
    MyDatePickerModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AppInterceptorService,
      multi: true
    },
    Utils,
    Constants,
    Urls,
    KerbrosAuthService,
    TaskService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
