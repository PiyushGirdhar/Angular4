import { Component, OnInit } from '@angular/core';
import { TaskService } from './../shared/services/task.service';
import { Constants } from './../shared/constants/constants';
import { IMyDpOptions } from 'mydatepicker';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {

  taskTypeValues: any;
  taskActionValues: any;
  frequencyValues: any;
  slaRegionValues: any;
  fileTypeValues: any;
  fileFormatValues: any;
  taskOwnedByValues: any;
  accountValues: any;
  folderDateValues: any;
  taggedAccounts: any = [];
  sendTaggedAccounts: any = [];
  showAccounts: boolean = false;
  itemsPerPage: number = this.constant.itemsPerPage;
  currentPage: number = this.constant.currentPage;
  submitData: any = [];
  myDatePickerOptions: IMyDpOptions = {
    dateFormat: this.constant.dateFormat,
    editableDateField: false
  };

  constructor(
    private taskAddService: TaskService,
    private constant: Constants
  ) { }

  // Get Task Type
  getTaskType(): void {
    this.taskAddService.getTaskType().subscribe(data => {
      this.taskTypeValues = data;
    });
  }

  // Get Task Action
  getTaskAction(): void {
    this.taskAddService.getTaskAction().subscribe(data => {
      this.taskActionValues = data;
    });
  }

  // Get Task Owned By
  getTaskOwnedBy(): void {
    this.taskAddService.getTaskOwnedBy().subscribe(data => {
      this.taskOwnedByValues = data;
    });
  }

  // Get Frequency
  getFrequency(): void {
    this.taskAddService.getFrequency().subscribe(data => {
      this.frequencyValues = data;
    });
  }

  // Get Sla Region
  getSlaRegion(): void {
    this.taskAddService.getSlaRegion().subscribe(data => {
      this.slaRegionValues = data;
    });
  }

  // Get File Type
  getFileType(): void {
    this.taskAddService.getFileType().subscribe(data => {
      this.fileTypeValues = data;
    });
  }

  // Get File Format
  getFileFormat(): void {
    this.taskAddService.getFileFormat().subscribe(data => {
      this.fileFormatValues = data;
    });
  }

  // Get Folder Date Format
  getFolderDateFormat(): void {
    this.taskAddService.getFolderDateFormat().subscribe(data => {
      this.folderDateValues = data;
    });
  }

  // Get Accounts
  getAccounts(): void {
    this.taskAddService.getAccounts().subscribe(data => {
      this.accountValues = data[this.constant.accountList];
    });
  }

  // Set selected Values OnInit
  setSelectedValues(): void {
    this.submitData.taskType = '';
    this.submitData.taskAction = '';
    this.submitData.taskOwnedByTeam = '';
    this.submitData.taskFrequencyCode = '';
    this.submitData.slaRegion = '';
    this.submitData.fileType = '';
    this.submitData.fileFormat = '';
    this.submitData.folderDateFormat = '';
  }

  // Add Task
  onTaskSubmit(data): void {
    const taskData = {
      activeFlag: this.constant.activeFlag,
      firstTaskDate: data.firstTaskDate.formatted,
      lastTaskDate: data.lastTaskDate.formatted,
      taskFileDetailRequest: {
        activeFlag: this.constant.activeFlag,
        fileType: data.fileType,
        numberOfFiles: data.numberOfFiles,
        fileFormat: data.fileFormat,
        nasPathFormat: data.nasPathFormat,
        folderDateFormat: data.folderDateFormat
      },
      slaRegion: data.slaRegion,
      slaType: data.slaType,
      taskAction: data.taskAction,
      taskDueDay: data.taskDueDay,
      taskFrequencyCode: data.taskFrequencyCode,
      taskName: data.taskName,
      taskOwnedByTeam: data.taskOwnedByTeam,
      taskType: data.taskType,
      taskMasterEntityMapping: this.sendTaggedAccounts
    };
    this.taskAddService.submitTask(taskData).subscribe(res => {
      console.log(res);
    });
  }

  // Change page in pagination
  onPageChange(number: number): void {
    this.currentPage = number;
  }

  // Tag accounts
  tagAccount(data): void {
    const pushData = {
      taskEntityType: data.accountName,
      taskEntityValue: data.accountId,
      fundCode: data.fundCode
    };
    const sendData = {
      taskEntityType: data.accountName,
      taskEntityValue: data.accountId
    };
    const pushTag = {};
    const sendTag = {};
    this.taggedAccounts.push(pushData);
    this.taggedAccounts = this.taggedAccounts.filter(obj => !pushTag[obj.taskEntityValue] && (pushTag[obj.taskEntityValue] = true));
    this.sendTaggedAccounts.push(sendData);
    this.sendTaggedAccounts = this.sendTaggedAccounts.filter(obj => !sendTag[obj.taskEntityValue] && (sendTag[obj.taskEntityValue] = true));
  }

  // Remove Tagged Account
  removeTag(id): void {
    this.taggedAccounts.splice(id, 1);
  }

  // Check If account or fund specific to show accounts
  checkForAcounts(): void {
    this.submitData.fileType === this.constant.accountSpecific ? this.showAccounts = true :
    this.submitData.fileType === this.constant.fundSpecific ? this.showAccounts = true : this.showAccounts = false;
    this.showAccounts ? this.getAccounts() : this.showAccounts = false;
    if (this.submitData.fileType === this.constant.generic) {
      this.submitData.numberOfFiles = 1;
    }
    this.submitData.fileType === this.constant.generic ? this.submitData.numberOfFiles = 1 : this.submitData.numberOfFiles = '';
  }

  ngOnInit(): void {
    this.getTaskType();
    this.getTaskAction();
    this.getTaskOwnedBy();
    this.getFrequency();
    this.getSlaRegion();
    this.getFileType();
    this.getFileFormat();
    this.getFolderDateFormat();
    this.setSelectedValues();
  }

}
