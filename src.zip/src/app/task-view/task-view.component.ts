import { Component, OnInit } from '@angular/core';
import { TaskService } from './../shared/services/task.service';
import { Constants } from './../shared/constants/constants';

@Component({
  selector: 'app-task-view',
  templateUrl: './task-view.component.html',
  styleUrls: ['./task-view.component.css']
})
export class TaskViewComponent implements OnInit {

  tasks: any;
  itemsPerPage: number = this.constant.itemsPerPage;
  currentPage: number = this.constant.currentPage;

  constructor(
    private taskViewService: TaskService,
    private constant: Constants
  ) { }

  // Get All tasks
  getAllTask(): void {
    this.taskViewService.getAllTask().subscribe(data => {
      this.tasks = data;
      console.log(this.tasks);
    });
  }

  // Change page in pagination
  onPageChange(number: number): void {
    this.currentPage = number;
  }

  ngOnInit(): void {
    this.getAllTask();
  }

}
