export const environment = {
  production: true,
  API_ENDPOINT: 'https://taskmanagement-prod.np2a.paas.bip.uk.fid-intl.com',
  KERBEROS_ENDPOINT: 'https://login-api-prod.npapps.paas.bip.uk.fid-intl.com/api/inst/kerb/v1'
};
